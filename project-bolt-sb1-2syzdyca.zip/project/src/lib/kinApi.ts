const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL as string;
const SUPABASE_ANON_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY as string;
const API_BASE = `${SUPABASE_URL}/functions/v1/kin-api`;

export function getLlmBaseUrl(deviceId: string): string {
  return `${API_BASE}/llm/${deviceId}`;
}

async function request<T>(path: string, init: RequestInit = {}): Promise<T> {
  const response = await fetch(`${API_BASE}${path}`, {
    ...init,
    headers: {
      Authorization: `Bearer ${SUPABASE_ANON_KEY}`,
      apikey: SUPABASE_ANON_KEY,
      "Content-Type": "application/json",
      ...init.headers,
    },
  });
  const body = await response.json().catch(() => null);
  if (!response.ok) {
    throw new Error(body?.error ?? `Request failed (${response.status})`);
  }
  return body as T;
}

export type UsageResponse = { secondsUsed: number; limitSeconds: number };

function isUsageResponse(value: unknown): value is UsageResponse {
  const body = value as UsageResponse | null;
  return (
    typeof body?.secondsUsed === "number" && typeof body?.limitSeconds === "number"
  );
}

async function requestUsage(path: string, init?: RequestInit): Promise<UsageResponse> {
  const body = await request<unknown>(path, init);
  if (!isUsageResponse(body)) throw new Error("Unexpected usage response");
  return body;
}

export function fetchUsage(deviceId: string, date: string): Promise<UsageResponse> {
  return requestUsage(`/usage/${deviceId}?date=${date}`);
}

export function recordUsage(
  deviceId: string,
  date: string,
  seconds: number,
): Promise<UsageResponse> {
  return requestUsage(`/usage/${deviceId}?date=${date}`, {
    method: "POST",
    body: JSON.stringify({ seconds }),
  });
}

export async function uploadFrame(deviceId: string, image: string): Promise<void> {
  await request(`/frame/${deviceId}`, {
    method: "POST",
    body: JSON.stringify({ image }),
  });
}

export async function clearFrame(deviceId: string): Promise<void> {
  await request(`/frame/${deviceId}`, { method: "DELETE" });
}

export const DEFAULT_VAPI_PUBLIC_KEY = "8bb38e7b-ee1c-4228-a5f4-aef041c9458c";

export type ApiSettings = { vapiPublicKey: string | null; geminiConfigured: boolean };

function isApiSettings(value: unknown): value is ApiSettings {
  const body = value as ApiSettings | null;
  return (
    typeof body?.geminiConfigured === "boolean" &&
    (body?.vapiPublicKey === null || typeof body?.vapiPublicKey === "string")
  );
}

async function requestSettings(init?: RequestInit): Promise<ApiSettings> {
  const body = await request<unknown>("/settings", init);
  if (!isApiSettings(body)) throw new Error("Unexpected settings response");
  return body;
}

export function fetchApiSettings(): Promise<ApiSettings> {
  return requestSettings();
}

export function saveApiSettings(update: {
  vapiPublicKey?: string;
  geminiApiKey?: string;
}): Promise<ApiSettings> {
  return requestSettings({ method: "PUT", body: JSON.stringify(update) });
}
