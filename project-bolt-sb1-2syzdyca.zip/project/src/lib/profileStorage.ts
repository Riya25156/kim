import type { CharacterId } from "@/lib/characters";
import { readValue, writeValue } from "@/lib/localDb";

export type UserProfile = {
  name: string;
  interests: string[];
  characterId: CharacterId | null;
};

const PROFILE_KEY = "profile";
const DEVICE_KEY = "deviceId";

export function loadProfile(): Promise<UserProfile | undefined> {
  return readValue<UserProfile>(PROFILE_KEY);
}

export function saveProfile(profile: UserProfile): Promise<void> {
  return writeValue(PROFILE_KEY, profile);
}

export async function loadOrCreateDeviceId(): Promise<string> {
  const existing = await readValue<string>(DEVICE_KEY);
  if (existing) return existing;
  const created = crypto.randomUUID();
  await writeValue(DEVICE_KEY, created);
  return created;
}
