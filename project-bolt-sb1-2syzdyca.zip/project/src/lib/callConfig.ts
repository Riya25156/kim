import { buildSystemPrompt, type Character } from "@/lib/characters";
import { getLlmBaseUrl } from "@/lib/kinApi";

type BuildCallConfigInput = {
  character: Character;
  name: string;
  interests: string[];
  deviceId: string;
  maxDurationSeconds: number;
};

export type CallConfig = ReturnType<typeof buildCallConfig>;

export function buildCallConfig({
  character,
  name,
  interests,
  deviceId,
  maxDurationSeconds,
}: BuildCallConfigInput) {
  const firstMessage =
    character.id === "ziva"
      ? `Hi ${name}, I'm Ziva. How are you feeling today?`
      : `Hey ${name}! Xen here. What are we crushing today?`;

  return {
    name: `KIN ${character.name}`,
    firstMessage,
    maxDurationSeconds,
    recordingEnabled: false,
    transcriber: {
      provider: "deepgram" as const,
      model: "nova-3",
      language: "multi" as const,
    },
    model: {
      provider: "custom-llm" as const,
      model: "gemini-2.5-flash",
      url: getLlmBaseUrl(deviceId),
      temperature: 0.8,
      messages: [
        { role: "system" as const, content: buildSystemPrompt(character, name, interests) },
      ],
    },
    voice: {
      provider: "vapi" as const,
      voiceId: character.voiceId,
      version: "2" as const,
      language: "auto" as const,
    },
    stopSpeakingPlan: {
      numWords: 0,
      voiceSeconds: 0.2,
      backoffSeconds: 0,
    },
  };
}
