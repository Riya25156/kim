import { useCallback, useEffect, useRef, useState } from "react";
import Vapi from "@vapi-ai/web";
import type { CallConfig } from "@/lib/callConfig";
import { requestMicrophoneAccess, unlockAudioPlayback } from "@/lib/microphone";

export type CallStatus = "idle" | "connecting" | "active";

type Turn = { role: "user" | "assistant"; text: string };

const MAX_RECONNECTS = 4;
const MIN_RECONNECT_SECONDS = 10;
const HISTORY_LIMIT = 20;
const RECONNECT_BASE_MS = 600;
const CONNECT_TIMEOUT_MS = 15_000;
const STABLE_CALL_MS = 20_000;

type TranscriptMessage = {
  type?: string;
  role?: string;
  transcriptType?: string;
  transcript?: string;
};

function resumeConfig(config: CallConfig, history: Turn[], maxDurationSeconds: number): CallConfig {
  const transcript = history.map((line) => `${line.role === "user" ? "User" : "You"}: ${line.text}`).join("\n");
  const resume = [
    "The connection dropped briefly and has been restored. Continue the conversation naturally from where it stopped.",
    "Do not greet the user again or mention the reconnect unless they ask.",
    transcript ? `Conversation so far:\n${transcript}` : "",
  ]
    .filter(Boolean)
    .join("\n");

  return {
    ...config,
    firstMessage: "",
    maxDurationSeconds,
    model: {
      ...config.model,
      messages: [...config.model.messages, { role: "system" as const, content: resume }],
    },
  };
}

export function useVapiSession(publicKey: string | null) {
  const vapiRef = useRef<Vapi | null>(null);
  const configRef = useRef<CallConfig | null>(null);
  const startedAtRef = useRef(0);
  const activeSinceRef = useRef(0);
  const endingRef = useRef(false);
  const restartingRef = useRef(false);
  const attemptsRef = useRef(0);
  const reconnectTimerRef = useRef<number | null>(null);
  const connectTimerRef = useRef<number | null>(null);
  const historyRef = useRef<Turn[]>([]);
  const scheduleReconnectRef = useRef<(() => void) | null>(null);

  const [status, setStatus] = useState<CallStatus>("idle");
  const [muted, setMuted] = useState(false);
  const [speaking, setSpeaking] = useState<"user" | "assistant" | null>(null);
  const [assistantLevel, setAssistantLevel] = useState(0);
  const [error, setError] = useState<string | null>(null);

  const clearTimers = useCallback(() => {
    if (reconnectTimerRef.current !== null) {
      window.clearTimeout(reconnectTimerRef.current);
      reconnectTimerRef.current = null;
    }
    if (connectTimerRef.current !== null) {
      window.clearTimeout(connectTimerRef.current);
      connectTimerRef.current = null;
    }
  }, []);

  const resetCallState = useCallback(() => {
    setStatus("idle");
    setMuted(false);
    setSpeaking(null);
    setAssistantLevel(0);
  }, []);

  const stopQuietly = useCallback(() => {
    restartingRef.current = true;
    try {
      vapiRef.current?.stop();
    } finally {
      restartingRef.current = false;
    }
  }, []);

  const dial = useCallback(async (config: CallConfig) => {
    const vapi = vapiRef.current;
    if (!vapi) throw new Error("Voice service is not ready");
    if (connectTimerRef.current !== null) window.clearTimeout(connectTimerRef.current);
    connectTimerRef.current = window.setTimeout(() => {
      connectTimerRef.current = null;
      stopQuietly();
      scheduleReconnectRef.current?.();
    }, CONNECT_TIMEOUT_MS);
    await vapi.start(config);
  }, [stopQuietly]);

  const scheduleReconnect = useCallback(() => {
    const config = configRef.current;
    if (!config || endingRef.current || reconnectTimerRef.current !== null) return;
    if (activeSinceRef.current && Date.now() - activeSinceRef.current > STABLE_CALL_MS) {
      attemptsRef.current = 0;
    }
    activeSinceRef.current = 0;
    clearTimers();
    stopQuietly();

    const remaining = Math.floor(config.maxDurationSeconds - (Date.now() - startedAtRef.current) / 1000);
    if (remaining < MIN_RECONNECT_SECONDS) {
      configRef.current = null;
      resetCallState();
      return;
    }
    if (attemptsRef.current >= MAX_RECONNECTS) {
      configRef.current = null;
      resetCallState();
      setError("The voice connection keeps dropping. Check your internet connection and start the call again.");
      return;
    }

    attemptsRef.current += 1;
    const delay = RECONNECT_BASE_MS * 2 ** (attemptsRef.current - 1);
    setStatus("connecting");
    setSpeaking(null);
    setError(null);

    reconnectTimerRef.current = window.setTimeout(() => {
      reconnectTimerRef.current = null;
      const latest = configRef.current;
      if (endingRef.current || !latest) return;
      const liveRemaining = Math.floor(latest.maxDurationSeconds - (Date.now() - startedAtRef.current) / 1000);
      dial(resumeConfig(latest, historyRef.current, liveRemaining)).catch(() => {
        scheduleReconnectRef.current?.();
      });
    }, delay);
  }, [clearTimers, dial, resetCallState, stopQuietly]);

  useEffect(() => {
    scheduleReconnectRef.current = scheduleReconnect;
  }, [scheduleReconnect]);

  useEffect(() => {
    if (!publicKey) return;

    let vapi: Vapi;
    try {
      vapi = new Vapi(publicKey);
    } catch {
      setError("Voice calling could not load in this browser. Reload the page and try again.");
      return;
    }
    vapiRef.current = vapi;

    vapi.on("call-start", () => {
      if (connectTimerRef.current !== null) {
        window.clearTimeout(connectTimerRef.current);
        connectTimerRef.current = null;
      }
      activeSinceRef.current = Date.now();
      setStatus("active");
      setError(null);
    });
    vapi.on("call-end", () => {
      if (restartingRef.current) return;
      if (endingRef.current || !configRef.current) {
        resetCallState();
        return;
      }
      scheduleReconnectRef.current?.();
    });
    vapi.on("speech-start", () => setSpeaking("assistant"));
    vapi.on("speech-end", () => setSpeaking(null));
    vapi.on("volume-level", (level: number) => setAssistantLevel(level));
    vapi.on("message", (message: TranscriptMessage) => {
      if (message.type !== "transcript" || message.transcriptType !== "final") return;
      if (!message.transcript) return;
      const role: Turn["role"] = message.role === "user" ? "user" : "assistant";
      historyRef.current = [...historyRef.current, { role, text: message.transcript }].slice(-HISTORY_LIMIT);
      if (role === "user") setSpeaking("user");
    });
    vapi.on("error", () => {
      if (restartingRef.current) return;
      scheduleReconnectRef.current?.();
    });

    return () => {
      endingRef.current = true;
      clearTimers();
      vapi.stop();
      vapiRef.current = null;
    };
  }, [publicKey, clearTimers, resetCallState]);

  const start = useCallback(
    async (config: CallConfig) => {
      if (!vapiRef.current) {
        setError("Voice calling is not configured for this app yet.");
        return;
      }
      clearTimers();
      endingRef.current = false;
      attemptsRef.current = 0;
      historyRef.current = [];
      configRef.current = config;
      startedAtRef.current = Date.now();
      setError(null);
      setStatus("connecting");
      try {
        await unlockAudioPlayback();
        await requestMicrophoneAccess();
      } catch {
        configRef.current = null;
        resetCallState();
        setError("Microphone access is blocked. Allow the microphone for this site in your browser settings and try again.");
        return;
      }
      try {
        await dial(config);
      } catch {
        configRef.current = null;
        resetCallState();
        setError("We could not start the call. Check that microphone access is allowed.");
      }
    },
    [clearTimers, dial, resetCallState],
  );

  const end = useCallback(() => {
    endingRef.current = true;
    configRef.current = null;
    clearTimers();
    vapiRef.current?.stop();
    resetCallState();
  }, [clearTimers, resetCallState]);

  const toggleMute = useCallback(() => {
    const vapi = vapiRef.current;
    if (!vapi) return;
    const next = !muted;
    vapi.setMuted(next);
    setMuted(next);
  }, [muted]);

  return {
    configured: Boolean(publicKey),
    status,
    muted,
    speaking,
    assistantLevel,
    error,
    start,
    end,
    toggleMute,
  };
}
