import { useCallback, useEffect, useRef, useState } from "react";
import { clearFrame, uploadFrame } from "@/lib/kinApi";

export type CameraFacing = "user" | "environment";

const FRAME_INTERVAL_MS = 2500;
const FRAME_MAX_WIDTH = 512;
const FRAME_QUALITY = 0.6;

export function useCamera(deviceId: string | null, streamFramesToAi: boolean) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const [facing, setFacing] = useState<CameraFacing>("user");
  const [enabled, setEnabled] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [frameError, setFrameError] = useState<string | null>(null);

  const releaseStream = useCallback(() => {
    streamRef.current?.getTracks().forEach((track) => track.stop());
    streamRef.current = null;
    if (videoRef.current) videoRef.current.srcObject = null;
  }, []);

  const stop = useCallback(() => {
    releaseStream();
    setEnabled(false);
    setFrameError(null);
    if (deviceId) clearFrame(deviceId).catch(() => undefined);
  }, [deviceId, releaseStream]);

  const start = useCallback(
    async (mode: CameraFacing) => {
      releaseStream();
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: { ideal: mode } },
          audio: false,
        });
        streamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          await videoRef.current.play().catch(() => undefined);
        }
        setError(null);
        setEnabled(true);
      } catch {
        setError("Camera access was blocked or no camera is available.");
        setEnabled(false);
      }
    },
    [releaseStream],
  );

  const toggle = useCallback(() => {
    if (enabled) stop();
    else start(facing);
  }, [enabled, facing, start, stop]);

  const flip = useCallback(() => {
    const next: CameraFacing = facing === "user" ? "environment" : "user";
    setFacing(next);
    if (enabled) start(next);
  }, [enabled, facing, start]);

  useEffect(() => {
    if (!enabled || !streamFramesToAi || !deviceId) return;
    const timer = window.setInterval(async () => {
      const video = videoRef.current;
      if (!video || video.videoWidth === 0) return;
      const scale = Math.min(1, FRAME_MAX_WIDTH / video.videoWidth);
      const canvas = document.createElement("canvas");
      canvas.width = Math.round(video.videoWidth * scale);
      canvas.height = Math.round(video.videoHeight * scale);
      const context = canvas.getContext("2d");
      if (!context) return;
      context.drawImage(video, 0, 0, canvas.width, canvas.height);
      try {
        await uploadFrame(deviceId, canvas.toDataURL("image/jpeg", FRAME_QUALITY));
        setFrameError(null);
      } catch {
        setFrameError("The AI cannot see your camera right now.");
      }
    }, FRAME_INTERVAL_MS);
    return () => window.clearInterval(timer);
  }, [enabled, streamFramesToAi, deviceId]);

  useEffect(() => {
    return () => releaseStream();
  }, [releaseStream]);

  return { videoRef, enabled, facing, error, frameError, toggle, flip, stop };
}
