import { useCallback, useEffect, useState } from "react";
import { fetchApiSettings, saveApiSettings, type ApiSettings } from "@/lib/kinApi";

type ApiSettingsState =
  | { status: "loading" }
  | { status: "error"; message: string }
  | { status: "ready"; settings: ApiSettings };

export type SaveApiSettingsUpdate = { vapiPublicKey?: string; geminiApiKey?: string };

export function useApiSettings() {
  const [state, setState] = useState<ApiSettingsState>({ status: "loading" });

  const load = useCallback(async () => {
    setState({ status: "loading" });
    try {
      const settings = await fetchApiSettings();
      setState({ status: "ready", settings });
    } catch {
      setState({ status: "error", message: "We could not load your API settings." });
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const save = useCallback(async (update: SaveApiSettingsUpdate) => {
    const settings = await saveApiSettings(update);
    setState({ status: "ready", settings });
  }, []);

  return { state, save, reload: load };
}
