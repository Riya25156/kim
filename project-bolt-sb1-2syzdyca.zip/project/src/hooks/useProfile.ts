import { useCallback, useEffect, useState } from "react";
import type { CharacterId } from "@/lib/characters";
import {
  loadOrCreateDeviceId,
  loadProfile,
  saveProfile,
  type UserProfile,
} from "@/lib/profileStorage";

type ProfileState =
  | { status: "loading" }
  | { status: "error"; message: string }
  | { status: "ready"; deviceId: string; profile: UserProfile | null };

export function useProfile() {
  const [state, setState] = useState<ProfileState>({ status: "loading" });

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const [profile, deviceId] = await Promise.all([loadProfile(), loadOrCreateDeviceId()]);
        if (!cancelled) setState({ status: "ready", deviceId, profile: profile ?? null });
      } catch {
        if (!cancelled) {
          setState({ status: "error", message: "Your saved details could not be read on this device." });
        }
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  const persist = useCallback(
    async (profile: UserProfile) => {
      await saveProfile(profile);
      setState((prev) => (prev.status === "ready" ? { ...prev, profile } : prev));
    },
    [],
  );

  const completeWelcome = useCallback(
    (name: string, interests: string[]) => persist({ name, interests, characterId: null }),
    [persist],
  );

  const chooseCharacter = useCallback(
    (characterId: CharacterId) => {
      if (state.status !== "ready" || !state.profile) return Promise.resolve();
      return persist({ ...state.profile, characterId });
    },
    [persist, state],
  );

  return { state, completeWelcome, chooseCharacter };
}
