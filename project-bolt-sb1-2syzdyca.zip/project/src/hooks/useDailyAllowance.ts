import { useCallback, useEffect, useRef, useState } from "react";
import { FREE_DAILY_LIMIT_SECONDS, localDateKey, msUntilLocalMidnight } from "@/lib/dailyTime";
import { fetchUsage, recordUsage } from "@/lib/kinApi";

const FLUSH_EVERY_SECONDS = 15;

export function useDailyAllowance(deviceId: string | null) {
  const [dateKey, setDateKey] = useState(localDateKey);
  const [usedSeconds, setUsedSeconds] = useState<number | null>(null);
  const [limitSeconds, setLimitSeconds] = useState(FREE_DAILY_LIMIT_SECONDS);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [inCall, setInCall] = useState(false);
  const [sessionSeconds, setSessionSeconds] = useState(0);
  const sessionRef = useRef(0);
  const flushedRef = useRef(0);
  const dateKeyRef = useRef(dateKey);
  dateKeyRef.current = dateKey;

  const loadUsage = useCallback(async () => {
    if (!deviceId) return;
    try {
      const usage = await fetchUsage(deviceId, dateKeyRef.current);
      setUsedSeconds(usage.secondsUsed);
      setLimitSeconds(usage.limitSeconds);
      setLoadError(null);
    } catch {
      setLoadError("We could not load your free time for today.");
    }
  }, [deviceId]);

  useEffect(() => {
    loadUsage();
  }, [loadUsage, dateKey]);

  useEffect(() => {
    const timer = window.setTimeout(
      () => setDateKey(localDateKey()),
      msUntilLocalMidnight() + 1000,
    );
    return () => window.clearTimeout(timer);
  }, [dateKey]);

  const flush = useCallback(async () => {
    if (!deviceId) return;
    const delta = sessionRef.current - flushedRef.current;
    if (delta <= 0) return;
    flushedRef.current = sessionRef.current;
    try {
      const usage = await recordUsage(deviceId, dateKeyRef.current, delta);
      setUsedSeconds(usage.secondsUsed);
      setLimitSeconds(usage.limitSeconds);
      setLoadError(null);
    } catch {
      flushedRef.current -= delta;
      setLoadError("We could not save your call time. It will retry shortly.");
    }
  }, [deviceId]);

  useEffect(() => {
    if (!inCall) return;
    const timer = window.setInterval(() => {
      sessionRef.current += 1;
      setSessionSeconds(sessionRef.current);
      if (sessionRef.current - flushedRef.current >= FLUSH_EVERY_SECONDS) flush();
    }, 1000);
    return () => window.clearInterval(timer);
  }, [inCall, flush]);

  const beginSession = useCallback(() => {
    sessionRef.current = 0;
    flushedRef.current = 0;
    setSessionSeconds(0);
    setInCall(true);
  }, []);

  const endSession = useCallback(async () => {
    setInCall(false);
    await flush();
  }, [flush]);

  const remainingSeconds =
    usedSeconds === null
      ? null
      : Math.max(0, limitSeconds - usedSeconds - (sessionSeconds - flushedRef.current));

  return {
    loaded: usedSeconds !== null,
    loadError,
    limitSeconds,
    remainingSeconds,
    beginSession,
    endSession,
    retry: loadUsage,
  };
}
