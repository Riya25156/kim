import { useState } from "react";
import { ArrowRight, Check, Settings, Sparkles } from "lucide-react";
import ApiSettingsModal from "@/components/ApiSettingsModal";
import AvatarCanvas from "@/components/AvatarCanvas";
import type { SaveApiSettingsUpdate } from "@/hooks/useApiSettings";
import { CHARACTERS, type CharacterId } from "@/lib/characters";
import type { ApiSettings } from "@/lib/kinApi";

type CharacterSelectProps = {
  name: string;
  initialCharacterId: CharacterId | null;
  apiSettings: ApiSettings;
  onSaveApiSettings: (update: SaveApiSettingsUpdate) => Promise<void>;
  onConfirm: (characterId: CharacterId) => Promise<void>;
};

export default function CharacterSelect({
  name,
  initialCharacterId,
  apiSettings,
  onSaveApiSettings,
  onConfirm,
}: CharacterSelectProps) {
  const [selected, setSelected] = useState<CharacterId>(initialCharacterId ?? "ziva");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const voiceReady = Boolean(apiSettings.vapiPublicKey) && apiSettings.geminiConfigured;

  const handleConfirm = async () => {
    setSaving(true);
    setError(null);
    try {
      await onConfirm(selected);
    } catch {
      setError("We could not save your choice. Please try again.");
      setSaving(false);
    }
  };

  return (
    <div className="flex min-h-screen flex-col px-5 py-10 sm:px-8">
      <header className="mx-auto w-full max-w-5xl animate-fade-up text-center">
        <div className="flex items-center justify-between">
          <span className="w-12" />
          <p className="inline-flex items-center gap-2 rounded-full border border-white/10 px-3 py-1 text-xs uppercase tracking-[0.2em] text-slate-400">
            <Sparkles className="h-3.5 w-3.5 text-neon-300" />
            Hi {name}
          </p>
          <button
            type="button"
            onClick={() => setSettingsOpen(true)}
            aria-label="Voice settings"
            className="icon-button relative"
          >
            <Settings className="h-5 w-5" />
            {!voiceReady && (
              <span className="absolute right-2.5 top-2.5 h-2 w-2 rounded-full bg-amber-400 shadow-[0_0_8px_rgba(251,191,36,0.8)]" />
            )}
          </button>
        </div>
        <h1 className="mt-5 text-3xl font-bold tracking-tight text-white sm:text-4xl">Choose your companion</h1>
        <p className="mt-3 text-slate-400">Pick the vibe you want on your next call.</p>
      </header>

      <div className="mx-auto mt-10 grid w-full max-w-4xl flex-1 grid-cols-1 gap-6 md:grid-cols-2">
        {CHARACTERS.map((character, index) => {
          const isSelected = selected === character.id;
          return (
            <button
              key={character.id}
              type="button"
              onClick={() => setSelected(character.id)}
              aria-pressed={isSelected}
              style={{ animationDelay: `${index * 120}ms` }}
              className={`glass-panel group relative flex animate-fade-up flex-col items-center p-7 text-center transition duration-300 hover:-translate-y-1 ${
                isSelected
                  ? "border-neon-400/60 bg-white/[0.07] shadow-glow"
                  : "hover:border-white/25 hover:bg-white/[0.06]"
              }`}
            >
              {isSelected && (
                <span className="absolute right-5 top-5 inline-flex h-7 w-7 items-center justify-center rounded-full bg-neon-400 text-ink-950">
                  <Check className="h-4 w-4" />
                </span>
              )}
              <AvatarCanvas
                character={character}
                level={0}
                active={isSelected}
                className="h-52 w-full sm:h-60"
              />
              <h2 className="mt-4 text-2xl font-bold text-white">{character.name}</h2>
              <p className="mt-1 text-sm text-slate-400">{character.tagline}</p>
              <div className="mt-4 flex flex-wrap justify-center gap-2">
                {character.traits.map((trait) => (
                  <span
                    key={trait}
                    className="rounded-full border border-white/10 px-3 py-1 text-xs text-slate-300"
                    style={{ borderColor: isSelected ? `${character.color}66` : undefined }}
                  >
                    {trait}
                  </span>
                ))}
              </div>
            </button>
          );
        })}
      </div>

      <div className="mx-auto mt-10 flex w-full max-w-md flex-col items-stretch gap-3">
        {error && (
          <p role="alert" className="rounded-2xl border border-rose-500/30 bg-rose-500/10 px-4 py-3 text-center text-sm text-rose-200">
            {error}
          </p>
        )}
        <button type="button" onClick={handleConfirm} disabled={saving} className="neon-button w-full">
          {saving ? "Saving..." : `Start with ${CHARACTERS.find((c) => c.id === selected)?.name}`}
          {!saving && <ArrowRight className="h-4 w-4" />}
        </button>
      </div>

      {settingsOpen && (
        <ApiSettingsModal
          settings={apiSettings}
          onSave={onSaveApiSettings}
          onClose={() => setSettingsOpen(false)}
        />
      )}
    </div>
  );
}
