import { useEffect, useRef } from "react";
import type { Character } from "@/lib/characters";

type AvatarCanvasProps = {
  character: Character;
  level: number;
  active: boolean;
  className?: string;
};

function withAlpha(hex: string, alpha: number): string {
  const value = hex.replace("#", "");
  const r = parseInt(value.slice(0, 2), 16);
  const g = parseInt(value.slice(2, 4), 16);
  const b = parseInt(value.slice(4, 6), 16);
  return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}

function drawOrb(ctx: CanvasRenderingContext2D, t: number, cx: number, cy: number, radius: number, level: number, character: Character, active: boolean) {
  const breath = Math.sin(t * 1.1) * 0.035 + (active ? 0.02 : 0);
  const r = radius * (1 + breath + level * 0.3);

  const aura = ctx.createRadialGradient(cx, cy, r * 0.4, cx, cy, r * 2.1);
  aura.addColorStop(0, withAlpha(character.glow, 0.45));
  aura.addColorStop(1, withAlpha(character.glow, 0));
  ctx.fillStyle = aura;
  ctx.beginPath();
  ctx.arc(cx, cy, r * 2.1, 0, Math.PI * 2);
  ctx.fill();

  for (let i = 0; i < 3; i++) {
    const ringRadius = r * (1.2 + i * 0.18) + Math.sin(t * 0.8 + i) * radius * 0.02;
    ctx.strokeStyle = withAlpha(character.color, 0.35 - i * 0.1);
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.arc(cx, cy, ringRadius, 0, Math.PI * 2);
    ctx.stroke();
  }

  const core = ctx.createRadialGradient(cx - r * 0.3, cy - r * 0.35, r * 0.1, cx, cy, r);
  core.addColorStop(0, "#ffffff");
  core.addColorStop(0.35, character.color);
  core.addColorStop(1, "#06121a");
  ctx.fillStyle = core;
  ctx.beginPath();
  ctx.arc(cx, cy, r, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = "rgba(255, 255, 255, 0.55)";
  ctx.beginPath();
  ctx.ellipse(cx - r * 0.35, cy - r * 0.42, r * 0.22, r * 0.12, -0.5, 0, Math.PI * 2);
  ctx.fill();
}

function drawSpark(ctx: CanvasRenderingContext2D, t: number, cx: number, cy: number, radius: number, level: number, character: Character, active: boolean) {
  const pulse = Math.abs(Math.sin(t * 2.6)) * 0.06 + (active ? 0.03 : 0);
  const r = radius * (0.92 + pulse + level * 0.35);

  const aura = ctx.createRadialGradient(cx, cy, r * 0.3, cx, cy, r * 2);
  aura.addColorStop(0, withAlpha(character.glow, 0.5));
  aura.addColorStop(1, withAlpha(character.glow, 0));
  ctx.fillStyle = aura;
  ctx.beginPath();
  ctx.arc(cx, cy, r * 2, 0, Math.PI * 2);
  ctx.fill();

  const ticks = 16;
  for (let i = 0; i < ticks; i++) {
    const angle = (i / ticks) * Math.PI * 2 + t * 1.4;
    const inner = r * 1.22;
    const outer = r * (1.32 + (i % 2) * 0.08 + level * 0.2);
    ctx.strokeStyle = withAlpha(character.color, i % 2 === 0 ? 0.9 : 0.4);
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    ctx.moveTo(cx + Math.cos(angle) * inner, cy + Math.sin(angle) * inner);
    ctx.lineTo(cx + Math.cos(angle) * outer, cy + Math.sin(angle) * outer);
    ctx.stroke();
  }

  ctx.save();
  ctx.translate(cx, cy);
  ctx.rotate(t * 0.9);
  ctx.beginPath();
  for (let i = 0; i < 6; i++) {
    const angle = (i / 6) * Math.PI * 2;
    const point = [Math.cos(angle) * r, Math.sin(angle) * r] as const;
    if (i === 0) ctx.moveTo(point[0], point[1]);
    else ctx.lineTo(point[0], point[1]);
  }
  ctx.closePath();
  const hex = ctx.createLinearGradient(-r, -r, r, r);
  hex.addColorStop(0, character.color);
  hex.addColorStop(1, character.glow);
  ctx.fillStyle = hex;
  ctx.fill();
  ctx.restore();

  ctx.fillStyle = "rgba(5, 7, 11, 0.85)";
  ctx.beginPath();
  ctx.arc(cx, cy, r * 0.38, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = withAlpha(character.color, 0.95);
  ctx.beginPath();
  ctx.arc(cx, cy, r * 0.18 + level * r * 0.1, 0, Math.PI * 2);
  ctx.fill();
}

export default function AvatarCanvas({ character, level, active, className }: AvatarCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const levelRef = useRef(level);
  const activeRef = useRef(active);

  useEffect(() => {
    levelRef.current = Math.min(1, Math.max(0, level));
  }, [level]);

  useEffect(() => {
    activeRef.current = active;
  }, [active]);

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext("2d");
    if (!canvas || !ctx) return;

    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const resize = () => {
      const rect = canvas.getBoundingClientRect();
      canvas.width = Math.max(1, Math.round(rect.width * dpr));
      canvas.height = Math.max(1, Math.round(rect.height * dpr));
    };
    resize();
    const observer = new ResizeObserver(resize);
    observer.observe(canvas);

    const startedAt = performance.now();
    let frame = 0;
    const render = (now: number) => {
      const t = (now - startedAt) / 1000;
      const { width, height } = canvas;
      const cx = width / 2;
      const cy = height / 2;
      const radius = Math.min(width, height) * 0.22;
      ctx.clearRect(0, 0, width, height);

      if (character.motion === "orb") {
        drawOrb(ctx, t, cx, cy, radius, levelRef.current, character, activeRef.current);
      } else {
        drawSpark(ctx, t, cx, cy, radius, levelRef.current, character, activeRef.current);
      }
      frame = requestAnimationFrame(render);
    };
    frame = requestAnimationFrame(render);

    return () => {
      cancelAnimationFrame(frame);
      observer.disconnect();
    };
  }, [character]);

  return (
    <canvas
      ref={canvasRef}
      role="img"
      aria-label={`${character.name} avatar`}
      className={className}
    />
  );
}
