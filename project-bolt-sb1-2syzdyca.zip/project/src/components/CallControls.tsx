import { Loader2, Mic, MicOff, Phone, PhoneOff, SwitchCamera, Video, VideoOff } from "lucide-react";
import type { CallStatus } from "@/hooks/useVapiSession";

type CallControlsProps = {
  status: CallStatus;
  muted: boolean;
  cameraOn: boolean;
  canStart: boolean;
  onStart: () => void;
  onEnd: () => void;
  onToggleMute: () => void;
  onToggleCamera: () => void;
  onFlipCamera: () => void;
};

export default function CallControls({
  status,
  muted,
  cameraOn,
  canStart,
  onStart,
  onEnd,
  onToggleMute,
  onToggleCamera,
  onFlipCamera,
}: CallControlsProps) {
  const inCall = status === "active";
  const connecting = status === "connecting";

  return (
    <div className="mx-auto flex w-full max-w-md items-center justify-center gap-4 px-5 pb-8 pt-4 sm:gap-5">
      <button
        type="button"
        onClick={onToggleMute}
        disabled={!inCall}
        aria-label={muted ? "Unmute microphone" : "Mute microphone"}
        aria-pressed={muted}
        className={`icon-button ${muted ? "border-rose-400/50 bg-rose-500/15 text-rose-200" : ""}`}
      >
        {muted ? <MicOff className="h-5 w-5" /> : <Mic className="h-5 w-5" />}
      </button>

      {inCall || connecting ? (
        <button
          type="button"
          onClick={onEnd}
          aria-label="End call"
          className="inline-flex h-20 w-20 items-center justify-center rounded-full bg-rose-500 text-white shadow-[0_0_40px_-6px_rgba(244,63,94,0.7)] transition duration-200 hover:bg-rose-400 active:scale-95"
        >
          <PhoneOff className="h-8 w-8" />
        </button>
      ) : (
        <button
          type="button"
          onClick={onStart}
          disabled={!canStart || connecting}
          aria-label="Start call"
          className="inline-flex h-20 w-20 items-center justify-center rounded-full bg-neon-400 text-ink-950 shadow-glow transition duration-200 hover:scale-105 hover:bg-neon-300 active:scale-95 disabled:cursor-not-allowed disabled:opacity-40 disabled:hover:scale-100"
        >
          {connecting ? <Loader2 className="h-8 w-8 animate-spin" /> : <Phone className="h-8 w-8" />}
        </button>
      )}

      <button
        type="button"
        onClick={onToggleCamera}
        aria-label={cameraOn ? "Turn camera off" : "Turn camera on"}
        aria-pressed={cameraOn}
        className={`icon-button ${cameraOn ? "border-neon-400/50 bg-neon-400/15 text-neon-300" : ""}`}
      >
        {cameraOn ? <Video className="h-5 w-5" /> : <VideoOff className="h-5 w-5" />}
      </button>

      <button
        type="button"
        onClick={onFlipCamera}
        disabled={!cameraOn}
        aria-label="Switch between front and back camera"
        className="icon-button"
      >
        <SwitchCamera className="h-5 w-5" />
      </button>
    </div>
  );
}
