import { useEffect } from "react";
import { ArrowLeft, Clock, Loader2 } from "lucide-react";
import AdPlaceholder from "@/components/AdPlaceholder";
import AvatarCanvas from "@/components/AvatarCanvas";
import CallControls from "@/components/CallControls";
import { useCamera } from "@/hooks/useCamera";
import { useDailyAllowance } from "@/hooks/useDailyAllowance";
import { useVapiSession } from "@/hooks/useVapiSession";
import { buildCallConfig } from "@/lib/callConfig";
import { formatClock } from "@/lib/dailyTime";
import type { Character } from "@/lib/characters";

type CallScreenProps = {
  character: Character;
  name: string;
  interests: string[];
  deviceId: string;
  vapiPublicKey: string | null;
  geminiConfigured: boolean;
  onBack: () => void;
};

export default function CallScreen({
  character,
  name,
  interests,
  deviceId,
  vapiPublicKey,
  geminiConfigured,
  onBack,
}: CallScreenProps) {
  const session = useVapiSession(vapiPublicKey);
  const allowance = useDailyAllowance(deviceId);
  const { beginSession, endSession, remainingSeconds, limitSeconds } = allowance;
  const camera = useCamera(deviceId, session.status === "active");
  const { stop: stopCamera, enabled: cameraOn } = camera;
  const { end: endVapi } = session;

  useEffect(() => {
    if (session.status !== "active") return;
    beginSession();
    return () => {
      stopCamera();
      void endSession();
    };
  }, [session.status, beginSession, endSession, stopCamera]);

  useEffect(() => {
    if (session.status === "active" && remainingSeconds === 0) endVapi();
  }, [session.status, remainingSeconds, endVapi]);

  const canStart =
    session.configured &&
    geminiConfigured &&
    allowance.loaded &&
    remainingSeconds !== null &&
    remainingSeconds > 0;

  const startCall = () => {
    if (!canStart || remainingSeconds === null) return;
    session.start(
      buildCallConfig({
        character,
        name,
        interests,
        deviceId,
        maxDurationSeconds: remainingSeconds,
      }),
    );
  };

  const freeTimeUsed = remainingSeconds === 0;
  const progress = remainingSeconds === null ? 0 : (remainingSeconds / limitSeconds) * 100;
  const messages = [
    !session.configured && "Add your Vapi public key in Voice settings on the home screen to start calls.",
    !geminiConfigured && "Add your Gemini API key in Voice settings on the home screen so KIN can reply.",
    allowance.loadError,
    session.error,
    camera.error,
    camera.frameError,
  ].filter((message): message is string => Boolean(message));

  return (
    <div className="relative flex min-h-screen flex-col">
      <header className="flex items-center justify-between px-5 py-4 sm:px-8">
        <button type="button" onClick={onBack} aria-label="Back to companions" className="icon-button">
          <ArrowLeft className="h-5 w-5" />
        </button>
        <div className="w-12" />
      </header>

      <div className="mx-auto flex w-full max-w-md justify-center px-5">
        <div
          className="inline-flex w-full items-center gap-3 rounded-2xl border border-white/10 bg-white/[0.04] px-4 py-3"
          aria-live="polite"
        >
          <Clock className="h-4 w-4 shrink-0 text-neon-300" />
          <div className="min-w-0 flex-1">
            <div className="flex items-baseline justify-between gap-2">
              <span className="text-sm text-slate-300">
                {freeTimeUsed ? "Free time used for today" : "Free time left today"}
              </span>
              <span className="font-bold tabular-nums text-white">
                {remainingSeconds === null ? "--:--" : formatClock(remainingSeconds)}
              </span>
            </div>
            <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-white/10">
              <div
                className="h-full rounded-full bg-gradient-to-r from-neon-500 to-neon-300 transition-[width] duration-1000 ease-linear"
                style={{ width: `${Math.min(100, progress)}%` }}
              />
            </div>
          </div>
          {!allowance.loaded && !allowance.loadError && <Loader2 className="h-4 w-4 animate-spin text-slate-400" />}
        </div>
      </div>

      <main className="relative flex flex-1 flex-col items-center justify-center px-5 pb-6 pt-4">
        <div className="absolute right-4 top-2 sm:right-8">
          <AdPlaceholder />
        </div>

        <div
          className={`absolute left-4 top-2 w-24 overflow-hidden rounded-2xl border border-white/15 bg-ink-900 shadow-lg sm:left-8 sm:w-28 ${
            cameraOn ? "block" : "hidden"
          }`}
        >
          <video
            ref={camera.videoRef}
            muted
            playsInline
            className="aspect-[3/4] w-full object-cover"
            style={{ transform: camera.facing === "user" ? "scaleX(-1)" : undefined }}
          />
          <span className="absolute bottom-1.5 left-1.5 rounded bg-black/50 px-1.5 py-0.5 text-[10px] text-white">
            {camera.facing === "user" ? "Front" : "Back"}
          </span>
        </div>

        <div className="flex w-full flex-col items-center gap-6">
          <AvatarCanvas
            character={character}
            level={session.speaking === "assistant" ? session.assistantLevel : 0}
            active={session.status !== "idle"}
            className="h-64 w-full max-w-xs sm:h-80 sm:max-w-sm"
          />

          {messages.length > 0 && (
            <div role="alert" className="w-full max-w-md space-y-2">
              {messages.map((message) => (
                <p
                  key={message}
                  className="rounded-2xl border border-rose-500/30 bg-rose-500/10 px-4 py-3 text-center text-sm text-rose-200"
                >
                  {message}
                </p>
              ))}
              {allowance.loadError && (
                <button type="button" onClick={allowance.retry} className="mx-auto block text-sm text-neon-300 underline-offset-4 hover:underline">
                  Try again
                </button>
              )}
            </div>
          )}
        </div>
      </main>

      <CallControls
        status={session.status}
        muted={session.muted}
        cameraOn={cameraOn}
        canStart={canStart}
        onStart={startCall}
        onEnd={endVapi}
        onToggleMute={session.toggleMute}
        onToggleCamera={camera.toggle}
        onFlipCamera={camera.flip}
      />
    </div>
  );
}
