import { useEffect, useState } from "react";
import { BadgeCheck, VolumeX } from "lucide-react";

const REFRESH_MS = 45_000;

const CREATIVES = [
  { headline: "Unlock unlimited calls", detail: "Go Premium and talk as long as you like", from: "#0e7490", to: "#164e63" },
  { headline: "Train smarter, every day", detail: "Personal coaching on your schedule", from: "#9a3412", to: "#431407" },
  { headline: "Learn any language", detail: "Practice speaking with your companion", from: "#0f766e", to: "#134e4a" },
];

export default function AdPlaceholder() {
  const [tick, setTick] = useState(0);

  useEffect(() => {
    const timer = window.setInterval(() => setTick((value) => value + 1), REFRESH_MS);
    return () => window.clearInterval(timer);
  }, []);

  const creative = CREATIVES[tick % CREATIVES.length];

  return (
    <aside
      aria-label="Advertisement placeholder"
      className="w-36 overflow-hidden rounded-2xl border border-white/10 bg-ink-900/80 shadow-lg backdrop-blur sm:w-44"
    >
      <div
        key={tick}
        className="relative aspect-video animate-fade-up overflow-hidden"
        style={{ background: `linear-gradient(135deg, ${creative.from}, ${creative.to})` }}
      >
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,rgba(255,255,255,0.18),transparent_55%)]" />
        <div className="relative flex h-full flex-col justify-end p-2.5">
          <p className="text-[11px] font-bold leading-tight text-white">{creative.headline}</p>
          <p className="mt-0.5 text-[10px] leading-snug text-white/75">{creative.detail}</p>
        </div>
        <span className="absolute left-2 top-2 inline-flex items-center gap-1 rounded bg-black/40 px-1.5 py-0.5 text-[9px] font-medium uppercase tracking-wider text-white/90">
          <VolumeX className="h-2.5 w-2.5" />
          Silent
        </span>
      </div>
      <div className="flex items-center justify-between px-2.5 py-2 text-[10px] text-slate-400">
        <span className="inline-flex items-center gap-1">
          <BadgeCheck className="h-3 w-3 text-neon-300" />
          Ad
        </span>
        <AdCountdown key={tick} />
      </div>
    </aside>
  );
}

function AdCountdown() {
  const [seconds, setSeconds] = useState(REFRESH_MS / 1000);

  useEffect(() => {
    const timer = window.setInterval(() => setSeconds((value) => Math.max(0, value - 1)), 1000);
    return () => window.clearInterval(timer);
  }, []);

  return <span className="tabular-nums">Refresh in {seconds}s</span>;
}
