import { useEffect, useId, useState, type FormEvent } from "react";
import { CheckCircle2, Circle, Eye, EyeOff, KeyRound, Loader2, Trash2, X } from "lucide-react";
import type { ApiSettings } from "@/lib/kinApi";
import type { SaveApiSettingsUpdate } from "@/hooks/useApiSettings";

type ApiSettingsModalProps = {
  settings: ApiSettings;
  onSave: (update: SaveApiSettingsUpdate) => Promise<void>;
  onClose: () => void;
};

export default function ApiSettingsModal({ settings, onSave, onClose }: ApiSettingsModalProps) {
  const titleId = useId();
  const vapiId = useId();
  const geminiId = useId();
  const [vapiDraft, setVapiDraft] = useState(settings.vapiPublicKey ?? "");
  const [geminiDraft, setGeminiDraft] = useState("");
  const [showGemini, setShowGemini] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const handleKey = (event: KeyboardEvent) => {
      if (event.key === "Escape" && !saving) onClose();
    };
    window.addEventListener("keydown", handleKey);
    return () => window.removeEventListener("keydown", handleKey);
  }, [onClose, saving]);

  const buildUpdate = (): SaveApiSettingsUpdate => {
    const update: SaveApiSettingsUpdate = {};
    const vapiTrimmed = vapiDraft.trim();
    if (vapiTrimmed !== (settings.vapiPublicKey ?? "")) update.vapiPublicKey = vapiTrimmed;
    if (geminiDraft.trim()) update.geminiApiKey = geminiDraft.trim();
    return update;
  };

  const submit = async (update: SaveApiSettingsUpdate) => {
    setSaving(true);
    setError(null);
    try {
      await onSave(update);
      onClose();
    } catch (err) {
      setError(err instanceof Error ? err.message : "We could not save your keys. Please try again.");
      setSaving(false);
    }
  };

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const update = buildUpdate();
    if (Object.keys(update).length === 0) {
      onClose();
      return;
    }
    submit(update);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/70 p-0 backdrop-blur-sm sm:items-center sm:p-6">
      <button
        type="button"
        aria-label="Close settings"
        tabIndex={-1}
        onClick={saving ? undefined : onClose}
        className="absolute inset-0 cursor-default"
      />
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        className="relative w-full max-w-lg animate-fade-up rounded-t-3xl border border-white/10 bg-ink-900 p-6 shadow-2xl sm:rounded-3xl sm:p-8"
      >
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-center gap-3">
            <span className="inline-flex h-10 w-10 items-center justify-center rounded-xl border border-neon-400/40 bg-neon-400/10 text-neon-300">
              <KeyRound className="h-5 w-5" />
            </span>
            <div>
              <h2 id={titleId} className="text-xl font-bold text-white">
                Voice settings
              </h2>
              <p className="text-sm text-slate-400">Connect your keys to enable calls.</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            disabled={saving}
            aria-label="Close settings"
            className="icon-button h-10 w-10"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="mt-7 space-y-6">
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label htmlFor={vapiId} className="text-sm font-medium text-slate-200">
                Vapi public key
              </label>
              <StatusChip configured={Boolean(settings.vapiPublicKey)} />
            </div>
            <input
              id={vapiId}
              type="text"
              value={vapiDraft}
              onChange={(event) => setVapiDraft(event.target.value)}
              autoComplete="off"
              spellCheck={false}
              placeholder="Paste your public key"
              className="w-full rounded-2xl border border-white/10 bg-ink-950 px-4 py-3 font-mono text-sm text-white placeholder:text-slate-500 transition focus:border-neon-400/60 focus:outline-none focus:ring-4 focus:ring-neon-400/15"
            />
            <p className="text-xs leading-relaxed text-slate-500">
              Found in your Vapi dashboard under API keys. This is the public key, safe to store here.
            </p>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label htmlFor={geminiId} className="text-sm font-medium text-slate-200">
                Google Gemini API key
              </label>
              <StatusChip configured={settings.geminiConfigured} />
            </div>
            <div className="relative">
              <input
                id={geminiId}
                type={showGemini ? "text" : "password"}
                value={geminiDraft}
                onChange={(event) => setGeminiDraft(event.target.value)}
                autoComplete="off"
                spellCheck={false}
                placeholder={settings.geminiConfigured ? "Saved. Enter a new key to replace it" : "Paste your Gemini key"}
                className="w-full rounded-2xl border border-white/10 bg-ink-950 py-3 pl-4 pr-12 font-mono text-sm text-white placeholder:text-slate-500 transition focus:border-neon-400/60 focus:outline-none focus:ring-4 focus:ring-neon-400/15"
              />
              <button
                type="button"
                onClick={() => setShowGemini((value) => !value)}
                aria-label={showGemini ? "Hide key" : "Show key"}
                className="absolute right-2 top-1/2 inline-flex h-8 w-8 -translate-y-1/2 items-center justify-center rounded-full text-slate-400 transition hover:bg-white/10 hover:text-white"
              >
                {showGemini ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </button>
            </div>
            <p className="text-xs leading-relaxed text-slate-500">
              Stored on KIN's secure server and never sent back to your browser. Create one in Google AI Studio.
            </p>
            {settings.geminiConfigured && (
              <button
                type="button"
                onClick={() => submit({ geminiApiKey: "" })}
                disabled={saving}
                className="inline-flex items-center gap-1.5 text-xs text-rose-300 transition hover:text-rose-200 disabled:opacity-50"
              >
                <Trash2 className="h-3.5 w-3.5" />
                Remove saved Gemini key
              </button>
            )}
          </div>

          {error && (
            <p role="alert" className="rounded-2xl border border-rose-500/30 bg-rose-500/10 px-4 py-3 text-sm text-rose-200">
              {error}
            </p>
          )}

          <div className="flex flex-col-reverse gap-3 sm:flex-row sm:justify-end">
            <button
              type="button"
              onClick={onClose}
              disabled={saving}
              className="rounded-full px-5 py-3 text-sm text-slate-300 transition hover:text-white disabled:opacity-50"
            >
              Cancel
            </button>
            <button type="submit" disabled={saving} className="neon-button">
              {saving && <Loader2 className="h-4 w-4 animate-spin" />}
              {saving ? "Saving..." : "Save keys"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

function StatusChip({ configured }: { configured: boolean }) {
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs ${
        configured
          ? "border-emerald-400/30 bg-emerald-400/10 text-emerald-300"
          : "border-white/10 text-slate-400"
      }`}
    >
      {configured ? <CheckCircle2 className="h-3.5 w-3.5" /> : <Circle className="h-3.5 w-3.5" />}
      {configured ? "Saved" : "Not added"}
    </span>
  );
}
