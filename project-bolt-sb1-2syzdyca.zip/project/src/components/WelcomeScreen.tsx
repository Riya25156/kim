import { useState, type FormEvent, type KeyboardEvent } from "react";
import { ArrowRight, Plus, X } from "lucide-react";

type WelcomeScreenProps = {
  onComplete: (name: string, interests: string[]) => Promise<void>;
};

const SUGGESTIONS = ["Gym", "Coding", "Anime", "Music", "Travel", "Cooking", "Reading", "Hindi", "Marathi"];
const MAX_INTERESTS = 8;

export default function WelcomeScreen({ onComplete }: WelcomeScreenProps) {
  const [name, setName] = useState("");
  const [interests, setInterests] = useState<string[]>([]);
  const [draft, setDraft] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const addInterest = (raw: string) => {
    const value = raw.trim().replace(/\s+/g, " ").slice(0, 24);
    if (!value) return;
    setInterests((prev) => {
      if (prev.length >= MAX_INTERESTS) return prev;
      if (prev.some((item) => item.toLowerCase() === value.toLowerCase())) return prev;
      return [...prev, value];
    });
    setDraft("");
  };

  const removeInterest = (value: string) => {
    setInterests((prev) => prev.filter((item) => item !== value));
  };

  const handleDraftKey = (event: KeyboardEvent<HTMLInputElement>) => {
    if (event.key === "Enter" || event.key === ",") {
      event.preventDefault();
      addInterest(draft);
    }
  };

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const trimmedName = name.trim();
    const pending = draft.trim() ? [...interests, draft.trim()] : interests;
    if (!trimmedName) {
      setError("Please tell us your name.");
      return;
    }
    if (pending.length === 0) {
      setError("Add at least one interest so KIN can personalize your conversations.");
      return;
    }
    setError(null);
    setSubmitting(true);
    try {
      await onComplete(trimmedName.slice(0, 40), pending.slice(0, MAX_INTERESTS));
    } catch {
      setError("We could not save your details on this device. Please try again.");
      setSubmitting(false);
    }
  };

  return (
    <div className="relative flex min-h-screen items-center justify-center px-5 py-12 sm:px-8">
      <div className="w-full max-w-md animate-fade-up">
        <div className="mb-10 text-center">
          <div className="mx-auto mb-5 inline-flex h-14 w-14 items-center justify-center rounded-2xl border border-neon-400/40 bg-neon-400/10 shadow-glow">
            <span className="text-2xl font-bold tracking-tight text-neon-300">K</span>
          </div>
          <h1 className="text-4xl font-bold tracking-tight text-white">KIN</h1>
          <p className="mt-3 text-base leading-relaxed text-slate-400">
            A voice companion that listens, sees and speaks your language.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="glass-panel space-y-7 p-7 sm:p-8">
          <div className="space-y-2">
            <label htmlFor="kin-name" className="text-sm font-medium text-slate-300">
              What should we call you?
            </label>
            <input
              id="kin-name"
              value={name}
              onChange={(event) => setName(event.target.value)}
              maxLength={40}
              autoComplete="given-name"
              placeholder="Your name"
              className="w-full rounded-2xl border border-white/10 bg-ink-900/80 px-4 py-3.5 text-lg text-white placeholder:text-slate-500 transition focus:border-neon-400/60 focus:outline-none focus:ring-4 focus:ring-neon-400/15"
            />
          </div>

          <div className="space-y-3">
            <label htmlFor="kin-interest" className="text-sm font-medium text-slate-300">
              What are you into?
            </label>
            <div className="flex gap-2">
              <input
                id="kin-interest"
                value={draft}
                onChange={(event) => setDraft(event.target.value)}
                onKeyDown={handleDraftKey}
                maxLength={24}
                placeholder="Type and press Enter"
                className="min-w-0 flex-1 rounded-2xl border border-white/10 bg-ink-900/80 px-4 py-3 text-white placeholder:text-slate-500 transition focus:border-neon-400/60 focus:outline-none focus:ring-4 focus:ring-neon-400/15"
              />
              <button
                type="button"
                onClick={() => addInterest(draft)}
                disabled={!draft.trim() || interests.length >= MAX_INTERESTS}
                aria-label="Add interest"
                className="icon-button h-auto w-12 rounded-2xl"
              >
                <Plus className="h-5 w-5" />
              </button>
            </div>

            <div className="flex flex-wrap gap-2 pt-1">
              {interests.map((interest) => (
                <span
                  key={interest}
                  className="inline-flex items-center gap-1.5 rounded-full border border-neon-400/40 bg-neon-400/10 py-1.5 pl-3.5 pr-2 text-sm text-neon-300"
                >
                  {interest}
                  <button
                    type="button"
                    onClick={() => removeInterest(interest)}
                    aria-label={`Remove ${interest}`}
                    className="rounded-full p-0.5 text-neon-300/70 transition hover:bg-neon-400/20 hover:text-white"
                  >
                    <X className="h-3.5 w-3.5" />
                  </button>
                </span>
              ))}
            </div>

            <div className="flex flex-wrap gap-2">
              {SUGGESTIONS.filter((s) => !interests.includes(s)).map((suggestion) => (
                <button
                  key={suggestion}
                  type="button"
                  onClick={() => addInterest(suggestion)}
                  disabled={interests.length >= MAX_INTERESTS}
                  className="rounded-full border border-white/10 px-3 py-1.5 text-sm text-slate-400 transition hover:border-white/30 hover:text-white disabled:opacity-40"
                >
                  {suggestion}
                </button>
              ))}
            </div>
          </div>

          {error && (
            <p role="alert" className="rounded-2xl border border-rose-500/30 bg-rose-500/10 px-4 py-3 text-sm text-rose-200">
              {error}
            </p>
          )}

          <button type="submit" disabled={submitting} className="neon-button w-full">
            {submitting ? "Saving..." : "Continue"}
            {!submitting && <ArrowRight className="h-4 w-4" />}
          </button>
          <p className="text-center text-xs text-slate-500">Saved on this device so KIN remembers you.</p>
        </form>
      </div>
    </div>
  );
}
