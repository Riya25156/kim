import { useState } from "react";
import { AlertTriangle, Loader2 } from "lucide-react";
import CallScreen from "@/components/CallScreen";
import CharacterSelect from "@/components/CharacterSelect";
import WelcomeScreen from "@/components/WelcomeScreen";
import { useApiSettings } from "@/hooks/useApiSettings";
import { useProfile } from "@/hooks/useProfile";
import { getCharacter } from "@/lib/characters";
import { DEFAULT_VAPI_PUBLIC_KEY } from "@/lib/kinApi";

function FullScreenMessage({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return (
    <div className="flex min-h-screen items-center justify-center px-6">
      <div className="glass-panel max-w-md p-8 text-center">
        <AlertTriangle className="mx-auto h-8 w-8 text-rose-300" />
        <p className="mt-4 text-base text-slate-200">{message}</p>
        <button
          type="button"
          onClick={onRetry ?? (() => window.location.reload())}
          className="neon-button mt-6"
        >
          {onRetry ? "Try again" : "Reload"}
        </button>
      </div>
    </div>
  );
}

function App() {
  const { state, completeWelcome, chooseCharacter } = useProfile();
  const { state: settingsState, save: saveApiSettings, reload: reloadApiSettings } = useApiSettings();
  const [inCall, setInCall] = useState(false);

  if (state.status === "loading") {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-neon-300" aria-label="Loading" />
      </div>
    );
  }

  if (state.status === "error") {
    return <FullScreenMessage message={state.message} />;
  }

  const { profile, deviceId } = state;
  if (!profile) return <WelcomeScreen onComplete={completeWelcome} />;

  if (settingsState.status === "loading") {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-neon-300" aria-label="Loading" />
      </div>
    );
  }

  if (settingsState.status === "error") {
    return <FullScreenMessage message={settingsState.message} onRetry={reloadApiSettings} />;
  }

  const apiSettings = {
    ...settingsState.settings,
    vapiPublicKey: settingsState.settings.vapiPublicKey ?? DEFAULT_VAPI_PUBLIC_KEY,
  };
  const character = profile.characterId ? getCharacter(profile.characterId) : null;
  if (!character || !inCall) {
    return (
      <CharacterSelect
        name={profile.name}
        initialCharacterId={profile.characterId}
        apiSettings={apiSettings}
        onSaveApiSettings={saveApiSettings}
        onConfirm={async (characterId) => {
          await chooseCharacter(characterId);
          setInCall(true);
        }}
      />
    );
  }

  return (
    <CallScreen
      key={character.id}
      character={character}
      name={profile.name}
      interests={profile.interests}
      deviceId={deviceId}
      vapiPublicKey={apiSettings.vapiPublicKey}
      geminiConfigured={apiSettings.geminiConfigured}
      onBack={() => setInCall(false)}
    />
  );
}

export default App;
