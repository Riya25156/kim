import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const GEMINI_MODEL = "gemini-2.5-flash";
const GEMINI_BASE = "https://generativelanguage.googleapis.com/v1beta/models";
const DAILY_LIMIT_SECONDS = 300;
const MAX_FRAME_CHARS = 400_000;
const MAX_KEY_CHARS = 512;
const DEVICE_PATTERN = "([A-Za-z0-9-]{8,64})";
const VAPI_KEY_SETTING = "vapi_public_key";
const GEMINI_KEY_SETTING = "gemini_api_key";
const RECOVERY_LINE = "Sorry, I lost my train of thought for a second. Can you say that again?";

const LANGUAGE_RULE =
  "Always reply in the same language the user is speaking, including natural Hinglish or Marathi mixes. " +
  "Keep replies short and conversational, because they will be spoken aloud. " +
  "If a camera frame is attached, you can see the user; reference what you see only when it is relevant.";

const supabase = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
);

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

function todayOrDate(value: string | null): string | null {
  if (!value) return null;
  return /^\d{4}-\d{2}-\d{2}$/.test(value) ? value : null;
}

async function getUsage(device: string, date: string) {
  const { data, error } = await supabase
    .from("kin_daily_usage")
    .select("seconds_used")
    .eq("device_id", device)
    .eq("usage_date", date)
    .maybeSingle();
  if (error) throw error;
  return data?.seconds_used ?? 0;
}

async function handleUsage(req: Request, device: string) {
  const date = todayOrDate(new URL(req.url).searchParams.get("date"));
  if (!date) return json({ error: "A valid date (YYYY-MM-DD) is required" }, 400);

  if (req.method === "GET") {
    const secondsUsed = await getUsage(device, date);
    return json({ secondsUsed, limitSeconds: DAILY_LIMIT_SECONDS });
  }

  const body = await req.json();
  const added = Number(body?.seconds);
  if (!Number.isFinite(added) || added < 0 || added > DAILY_LIMIT_SECONDS) {
    return json({ error: "seconds must be between 0 and 300" }, 400);
  }

  const current = await getUsage(device, date);
  const secondsUsed = Math.min(DAILY_LIMIT_SECONDS, current + Math.round(added));
  const { error } = await supabase.from("kin_daily_usage").upsert(
    { device_id: device, usage_date: date, seconds_used: secondsUsed, updated_at: new Date().toISOString() },
    { onConflict: "device_id,usage_date" },
  );
  if (error) throw error;
  return json({ secondsUsed, limitSeconds: DAILY_LIMIT_SECONDS });
}

async function handleFrame(req: Request, device: string) {
  if (req.method === "DELETE") {
    const { error } = await supabase.from("kin_frames").delete().eq("device_id", device);
    if (error) throw error;
    return json({ ok: true });
  }
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);
  const body = await req.json();
  const raw = typeof body?.image === "string" ? body.image : "";
  const base64 = raw.replace(/^data:image\/\w+;base64,/, "");
  if (!base64 || base64.length > MAX_FRAME_CHARS) {
    return json({ error: "A JPEG frame under the size limit is required" }, 400);
  }

  const { error } = await supabase.from("kin_frames").upsert(
    { device_id: device, image_base64: base64, updated_at: new Date().toISOString() },
    { onConflict: "device_id" },
  );
  if (error) throw error;
  return json({ ok: true });
}

async function readSetting(key: string): Promise<string | null> {
  const { data, error } = await supabase
    .from("kin_app_settings")
    .select("value")
    .eq("key", key)
    .maybeSingle();
  if (error) throw error;
  return data?.value ?? null;
}

async function writeSetting(key: string, value: string | null) {
  if (value === null) {
    const { error } = await supabase.from("kin_app_settings").delete().eq("key", key);
    if (error) throw error;
    return;
  }
  const { error } = await supabase.from("kin_app_settings").upsert(
    { key, value, updated_at: new Date().toISOString() },
    { onConflict: "key" },
  );
  if (error) throw error;
}

async function settingsResponse() {
  const [vapiPublicKey, gemini] = await Promise.all([
    readSetting(VAPI_KEY_SETTING),
    readSetting(GEMINI_KEY_SETTING),
  ]);
  return json({ vapiPublicKey, geminiConfigured: Boolean(gemini) });
}

type KeyUpdate = { present: false } | { present: true; value: string | null } | { present: "invalid" };

function parseKeyUpdate(value: unknown, pattern?: RegExp): KeyUpdate {
  if (value === undefined) return { present: false };
  if (typeof value !== "string") return { present: "invalid" };
  const trimmed = value.trim();
  if (trimmed === "") return { present: true, value: null };
  if (trimmed.length > MAX_KEY_CHARS || (pattern && !pattern.test(trimmed))) return { present: "invalid" };
  return { present: true, value: trimmed };
}

async function handleSettings(req: Request) {
  if (req.method === "GET") return settingsResponse();
  if (req.method !== "PUT") return json({ error: "Method not allowed" }, 405);

  const body = await req.json();
  const vapi = parseKeyUpdate(body?.vapiPublicKey, /^[A-Za-z0-9-]+$/);
  const gemini = parseKeyUpdate(body?.geminiApiKey);
  if (vapi.present === "invalid" || gemini.present === "invalid") {
    return json({ error: "That key does not look valid. Check it and try again." }, 400);
  }
  if (vapi.present === true) await writeSetting(VAPI_KEY_SETTING, vapi.value);
  if (gemini.present === true) await writeSetting(GEMINI_KEY_SETTING, gemini.value);
  return settingsResponse();
}

type ChatMessage = { role: string; content: unknown };
type GeminiPart = { text: string } | { inlineData: { mimeType: string; data: string } };
type GeminiTurn = { role: "user" | "model"; parts: GeminiPart[] };
type GeminiEvent = { candidates?: { content?: { parts?: { text?: string }[] } }[] };

function textOf(content: unknown): string {
  if (typeof content === "string") return content;
  if (Array.isArray(content)) {
    return content
      .map((part) => (part && typeof part === "object" && "text" in part ? String(part.text) : ""))
      .join(" ");
  }
  return "";
}

async function latestFrame(device: string): Promise<string | null> {
  const { data, error } = await supabase
    .from("kin_frames")
    .select("image_base64")
    .eq("device_id", device)
    .maybeSingle();
  if (error) throw error;
  return data?.image_base64 ?? null;
}

function buildGeminiBody(messages: ChatMessage[], frame: string | null) {
  const systemText = messages
    .filter((m) => m.role === "system")
    .map((m) => textOf(m.content))
    .join("\n\n");

  const contents: GeminiTurn[] = messages
    .filter((m) => m.role === "user" || m.role === "assistant")
    .map((m) => ({
      role: m.role === "assistant" ? "model" : "user",
      parts: [{ text: textOf(m.content) || " " }],
    }));

  if (frame) {
    const lastUser = [...contents].reverse().find((t) => t.role === "user");
    lastUser?.parts.push({ inlineData: { mimeType: "image/jpeg", data: frame } });
  }

  return JSON.stringify({
    systemInstruction: { parts: [{ text: `${systemText}\n\n${LANGUAGE_RULE}` }] },
    contents,
    generationConfig: { temperature: 0.8, maxOutputTokens: 400 },
  });
}

async function requestGemini(action: string, body: string): Promise<Response> {
  const apiKey = await readSetting(GEMINI_KEY_SETTING);
  if (!apiKey) throw new Error("The Gemini API key has not been added yet");

  const response = await fetch(`${GEMINI_BASE}/${GEMINI_MODEL}:${action}`, {
    method: "POST",
    headers: { "Content-Type": "application/json", "x-goog-api-key": apiKey },
    body,
  });
  if (!response.ok || !response.body) {
    throw new Error(`Gemini request failed (${response.status})`);
  }
  return response;
}

function geminiText(event: GeminiEvent): string {
  return (event.candidates?.[0]?.content?.parts ?? []).map((part) => part.text ?? "").join("");
}

function completionChunk(id: string, content: string | null, finish: "stop" | null) {
  return {
    id,
    object: "chat.completion.chunk",
    created: Math.floor(Date.now() / 1000),
    model: GEMINI_MODEL,
    choices: [
      {
        index: 0,
        delta: content === null ? {} : { role: "assistant", content },
        finish_reason: finish,
      },
    ],
  };
}

function relayGeminiStream(id: string, upstream: ReadableStream<Uint8Array>): ReadableStream<Uint8Array> {
  const encoder = new TextEncoder();
  const decoder = new TextDecoder();
  const reader = upstream.getReader();
  let buffer = "";

  const emit = (controller: ReadableStreamDefaultController<Uint8Array>, chunk: unknown) => {
    controller.enqueue(encoder.encode(`data: ${JSON.stringify(chunk)}\n\n`));
  };
  const finish = (controller: ReadableStreamDefaultController<Uint8Array>) => {
    emit(controller, completionChunk(id, null, "stop"));
    controller.enqueue(encoder.encode("data: [DONE]\n\n"));
    controller.close();
  };

  return new ReadableStream<Uint8Array>({
    async pull(controller) {
      try {
        const { done, value } = await reader.read();
        if (done) {
          finish(controller);
          return;
        }
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n");
        buffer = lines.pop() ?? "";
        for (const line of lines) {
          if (!line.startsWith("data:")) continue;
          const text = geminiText(JSON.parse(line.slice(5)) as GeminiEvent);
          if (text) emit(controller, completionChunk(id, text, null));
        }
      } catch {
        emit(controller, completionChunk(id, RECOVERY_LINE, null));
        finish(controller);
      }
    },
    cancel() {
      reader.cancel();
    },
  });
}

async function handleChat(req: Request, device: string) {
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);
  const body = await req.json();
  const messages: ChatMessage[] = Array.isArray(body?.messages) ? body.messages : [];
  const frame = await latestFrame(device);
  const geminiBody = buildGeminiBody(messages, frame);
  const id = `chatcmpl-kin-${crypto.randomUUID()}`;

  if (body?.stream !== true) {
    const response = await requestGemini("generateContent", geminiBody);
    const result = await response.json();
    const text = (result?.candidates?.[0]?.content?.parts ?? [])
      .map((p: { text?: string }) => p.text ?? "")
      .join("");
    return json({
      id,
      object: "chat.completion",
      created: Math.floor(Date.now() / 1000),
      model: GEMINI_MODEL,
      choices: [{ index: 0, message: { role: "assistant", content: text }, finish_reason: "stop" }],
    });
  }

  const upstream = await requestGemini("streamGenerateContent?alt=sse", geminiBody);
  return new Response(relayGeminiStream(id, upstream.body!), {
    headers: {
      ...corsHeaders,
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache",
    },
  });
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const { pathname } = new URL(req.url);

    if (pathname.endsWith("/settings")) return await handleSettings(req);

    const usage = pathname.match(new RegExp(`/usage/${DEVICE_PATTERN}$`));
    if (usage) return await handleUsage(req, usage[1]);

    const frame = pathname.match(new RegExp(`/frame/${DEVICE_PATTERN}$`));
    if (frame) return await handleFrame(req, frame[1]);

    const chat = pathname.match(new RegExp(`/llm/${DEVICE_PATTERN}/chat/completions$`));
    if (chat) return await handleChat(req, chat[1]);

    return json({ error: "Not found" }, 404);
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unexpected server error";
    return json({ error: message }, 500);
  }
});
