/*
# Create KIN app settings table

1. New Tables
- `kin_app_settings`: small key/value store for the API keys that the voice calling needs.
  - `key` (text, primary key): setting name, e.g. the Vapi public key or the Gemini API key.
  - `value` (text, not null): the stored value.
  - `updated_at` (timestamptz): when the value was last changed.

2. Security
- Row level security is enabled, with no policies for the public `anon` or `authenticated` roles.
- Browsers cannot read or write this table directly. Only the server-side function (service role) can access it, so the Gemini key is never sent back to the browser.
- `service_role` receives the table privileges it needs.

3. Important notes
- This is a new table; no existing data is changed or removed.
- Statements are idempotent and safe to re-run.
*/

CREATE TABLE IF NOT EXISTS kin_app_settings (
  key text PRIMARY KEY,
  value text NOT NULL,
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE kin_app_settings ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT, UPDATE, DELETE ON kin_app_settings TO service_role;
