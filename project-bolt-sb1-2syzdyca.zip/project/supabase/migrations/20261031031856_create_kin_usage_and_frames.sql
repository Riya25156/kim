/*
# Create KIN usage and live-frame tables

1. New Tables
- `kin_daily_usage`: how many seconds of free call time each device has used on each local calendar day.
  - `device_id` (text, part of primary key): random anonymous ID generated in the browser.
  - `usage_date` (date, part of primary key): the device's local date, so the limit resets at local midnight.
  - `seconds_used` (integer, default 0): running total for that day.
- `kin_frames`: the most recent camera frame sent by each device, used so the AI can "see" the user.
  - `device_id` (text, primary key)
  - `image_base64` (text): one JPEG frame encoded as base64.
  - `updated_at` (timestamptz): when the frame was last replaced.

2. Security
- Row level security is enabled on both tables.
- No policies are granted to the public `anon` or `authenticated` roles, so browsers cannot read or write these tables directly.
- Only the server-side function (which uses the service role key) can access them. `service_role` receives the table privileges it needs.

3. Important notes
- No data is removed or altered; these are new tables.
- Statements are idempotent and safe to re-run.
*/

CREATE TABLE IF NOT EXISTS kin_daily_usage (
  device_id text NOT NULL,
  usage_date date NOT NULL,
  seconds_used integer NOT NULL DEFAULT 0,
  updated_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (device_id, usage_date)
);

CREATE TABLE IF NOT EXISTS kin_frames (
  device_id text PRIMARY KEY,
  image_base64 text NOT NULL,
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE kin_daily_usage ENABLE ROW LEVEL SECURITY;
ALTER TABLE kin_frames ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT, UPDATE, DELETE ON kin_daily_usage TO service_role;
GRANT SELECT, INSERT, UPDATE, DELETE ON kin_frames TO service_role;
